/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hp;

/**
 *
 * @author RPR-C80A404ES
 */
public class registrarse {
    private int id_registrarse;
    private int telefono;
    private String nombre;
    private String correo;
    private String contraseña;
    private String direccion;

    public int getId_registrarse() {
        return id_registrarse;
    }

    public int getTelefono() {
        return telefono;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCorreo() {
        return correo;
    }

    public String getContraseña() {
        return contraseña;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setId_registrarse(int id_registrarse) {
        this.id_registrarse = id_registrarse;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

   
    public String mostrardatos() {
        return "pagina_2{" + "id_registrarse=" + id_registrarse + ", telefono=" + telefono + ", nombre=" + nombre + ", correo=" + correo + ", contrase\u00f1a=" + contraseña + ", direccion=" + direccion + '}';
    }
    
    
}
