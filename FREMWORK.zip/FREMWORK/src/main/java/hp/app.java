/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hp;

/**
 *
 * @author RPR-C80A404ES
 */
public class app {
    private int id_app;

    public int getId_app() {
        return id_app;
    }

    public void setId_app(int id_app) {
        this.id_app = id_app;
    }

    
    public String mostrardatos() {
        return "app{" + "id_app=" + id_app + '}';
    }
    
    
}
