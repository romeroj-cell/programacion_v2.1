/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hp;

/**
 *
 * @author RPR-C80A404ES
 */
public class pagina_3 {
    private int id_carrito;
    private int cantidad_productos;
   private String finalizar_compra;
   private String volver;

    public int getId_carrito() {
        return id_carrito;
    }

    public int getCantidad_productos() {
        return cantidad_productos;
    }

    public String getFinalizar_compra() {
        return finalizar_compra;
    }

    public String getVolver() {
        return volver;
    }

    public void setId_carrito(int id_carrito) {
        this.id_carrito = id_carrito;
    }

    public void setCantidad_productos(int cantidad_productos) {
        this.cantidad_productos = cantidad_productos;
    }

    public void setFinalizar_compra(String finalizar_compra) {
        this.finalizar_compra = finalizar_compra;
    }

    public void setVolver(String volver) {
        this.volver = volver;
    }

   
    public String mostrardatos() {
        return "pagina_3{" + "id_carrito=" + id_carrito + ", cantidad_productos=" + cantidad_productos + ", finalizar_compra=" + finalizar_compra + ", volver=" + volver + '}';
    }
   
   
}
