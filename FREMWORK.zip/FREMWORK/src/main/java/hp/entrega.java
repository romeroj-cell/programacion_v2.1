/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hp;

/**
 *
 * @author RPR-C80A404ES
 */
public class entrega {
    private int id_entrega;
    private int compra_y_recoje;
    private int envio_a_domicilio;
    private String selec_ciudad;
    private String selec_almacen;
    private String confirmar;

    public int getId_entrega() {
        return id_entrega;
    }

    public int getCompra_y_recoje() {
        return compra_y_recoje;
    }

    public int getEnvio_a_domicilio() {
        return envio_a_domicilio;
    }

    public String getSelec_ciudad() {
        return selec_ciudad;
    }

    public String getSelec_almacen() {
        return selec_almacen;
    }

    public String getConfirmar() {
        return confirmar;
    }

    public void setId_entrega(int id_entrega) {
        this.id_entrega = id_entrega;
    }

    public void setCompra_y_recoje(int compra_y_recoje) {
        this.compra_y_recoje = compra_y_recoje;
    }

    public void setEnvio_a_domicilio(int envio_a_domicilio) {
        this.envio_a_domicilio = envio_a_domicilio;
    }

    public void setSelec_ciudad(String selec_ciudad) {
        this.selec_ciudad = selec_ciudad;
    }

    public void setSelec_almacen(String selec_almacen) {
        this.selec_almacen = selec_almacen;
    }

    public void setConfirmar(String confirmar) {
        this.confirmar = confirmar;
    }

    
    public String mostardatos() {
        StringBuilder sb = new StringBuilder();
        sb.append("entrega{");
        sb.append("id_entrega=").append(id_entrega);
        sb.append(", compra_y_recoje=").append(compra_y_recoje);
        sb.append(", envio_a_domicilio=").append(envio_a_domicilio);
        sb.append(", selec_ciudad=").append(selec_ciudad);
        sb.append(", selec_almacen=").append(selec_almacen);
        sb.append(", confirmar=").append(confirmar);
        sb.append('}');
        return sb.toString();
    }
    
    
}
