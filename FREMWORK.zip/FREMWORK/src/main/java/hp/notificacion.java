/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hp;

/**
 *
 * @author RPR-C80A404ES
 */
public class notificacion {
    private int id_notificaciones;
    private String leer;
    private int marcar_leido;

    public int getId_notificaciones() {
        return id_notificaciones;
    }

    public String getLeer() {
        return leer;
    }

    public int getMarcar_leido() {
        return marcar_leido;
    }

    public void setId_notificaciones(int id_notificaciones) {
        this.id_notificaciones = id_notificaciones;
    }

    public void setLeer(String leer) {
        this.leer = leer;
    }

    public void setMarcar_leido(int marcar_leido) {
        this.marcar_leido = marcar_leido;
    }

    
    public String mostrardatos() {
        return "notificacion{" + "id_notificaciones=" + id_notificaciones + ", leer=" + leer + ", marcar_leido=" + marcar_leido + '}';
    }
    
    
}
